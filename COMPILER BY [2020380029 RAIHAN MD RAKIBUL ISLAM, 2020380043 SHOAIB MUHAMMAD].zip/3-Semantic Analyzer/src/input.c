#include<stdio.h>
void func(){
	int a;
}
void main()
{
	
	int a=10,b;
	char c;
	int f[100][10];
	a=b;
	a=b+12;
	printf("\nHello World");
	scanf();
	{
	int y;
	int a;
	}
	
	
}

