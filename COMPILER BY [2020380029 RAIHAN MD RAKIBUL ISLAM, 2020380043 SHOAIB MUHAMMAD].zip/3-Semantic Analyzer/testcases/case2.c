// Testcase to check undeclared variables
#include<stdio.h>
int main()
{
	int a=10,b=50,c=10;
	d = a+b;
	printf("The sum of %d + %d = %d",a,b,d);
}
