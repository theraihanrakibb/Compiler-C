//Testcase to check multiple declaration 

#include <stdio.h>
int main()
{
	int a = 5, b = 3;
	float x;
	char b;

	int a = b + 10;
}
