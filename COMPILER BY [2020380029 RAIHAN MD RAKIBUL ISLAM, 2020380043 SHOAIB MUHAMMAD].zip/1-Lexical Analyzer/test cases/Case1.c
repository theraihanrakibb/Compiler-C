// Test case to check Pre Processor Directives declarations

#include <stdio.h>
#include "userHeader.h"
#define size 10

#include<<math.h> 

int main(){
	int a=5;
	char c='H';
	char str[]="Hello World";
	return 1;
	
}
