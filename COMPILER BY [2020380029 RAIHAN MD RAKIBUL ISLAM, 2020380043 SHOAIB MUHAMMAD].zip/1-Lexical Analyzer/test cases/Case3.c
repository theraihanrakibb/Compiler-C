// Test case to check relational, logical and arithmetic operators

#include<stdio.h>
void main(){
		
		int a=1,b=2,c=3,d;
		a++;
		--b;
		c=a+b;
		d+=a;
		d=a||b;
		c=a%b;
		d=a++c;
		a=c+/c;
		
		d=a>b;
		
		
}
