// Test case to check int and char constants,string constants,
// keywords, punctuators and variables

#include<stdio.h>
void main(){
	int a=25;
	char c='h';
	char c='abc
	char arr1[10]="hello World";
	char arr2[10]="hello;
	return 1;
	

}
