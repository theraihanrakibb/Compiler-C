// test case to check single and multi line comments 

#include<stdio.h>
void main()
{
	// this is a single line comment
	
	/// this is also valid comment
	
	/* this is 
	a multi line 
	comment */
	
	/* this is 
	a /* nested */
	comment */
	
	invalid comment */ 
	
	/* invalid comment
	
	
}
