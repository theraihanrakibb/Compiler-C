//testcase to check main function errors
#include<stdio.h>
int main();
int main(){
	int y;
	y=20;
}
