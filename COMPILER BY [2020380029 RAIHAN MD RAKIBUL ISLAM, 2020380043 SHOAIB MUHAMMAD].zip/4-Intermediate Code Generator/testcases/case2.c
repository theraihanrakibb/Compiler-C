//testcase to generate control statments
#include<stdio.h>
int main(){
	int a;
	float t;
	a=20;
	if(a<30){
		t=3.0;
	}
	else{
		t=4.0;
	}
	return 2;
}
