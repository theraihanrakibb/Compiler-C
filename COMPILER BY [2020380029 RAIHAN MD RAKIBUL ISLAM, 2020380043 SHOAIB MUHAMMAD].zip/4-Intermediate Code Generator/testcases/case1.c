//Testcase generate simple expresion statements
#include<stdio.h>
int main(){
	int a;
	float t;
	a=10;
	t=t*10;
	return 1;
}
