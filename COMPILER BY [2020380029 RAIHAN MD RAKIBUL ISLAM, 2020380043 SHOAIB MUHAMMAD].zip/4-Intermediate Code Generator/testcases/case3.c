//testcase to check looping statements
#include<stdio.h>
int main(){
	int i,s;
	s=0;
	for(i=0;i<10;i=i+2){
		s=s+i;
	}
	return 2;
}
