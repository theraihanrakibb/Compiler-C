//testcase to generate different functions code
#include<stdio.h>
int func(int x,int y);
int func1(){
	int s;
	s=56;
}
int main(){
	int a;
	a=20;
	return 1;
}
