#include <stdlib.h>
int func(int a,int b);
int main (){
	int a;
	int a;
	a=a+10;
	while(a<10){
		a=a+34;
		printf("\nHello");
	}
	return 0;
	

}

