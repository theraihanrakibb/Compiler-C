//Testcase to check function decleration and parameter passing

#include<stdio.h>
int main(){
	
	int a[]={1,2,3,4};
	function1();
}
void function1(){
	printf("\nHello World");
}

