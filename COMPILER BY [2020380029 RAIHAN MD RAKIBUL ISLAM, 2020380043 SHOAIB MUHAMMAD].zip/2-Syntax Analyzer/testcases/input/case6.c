//Testcase to check missing semicolon ,unbalanced parenthesis 
#include<stdio.h>
int main(){
	int a=0,b=45,c=10;
	a=a+b

}
}
