//testcase 1 for parse tree
#include<stdio.h>
#define x 3
void main()
{
	int a=4,b=5;
	int d[2]={3,5};
	if(a<10)
		if(a>10)
			a=a+1;
		else 
			a=a-1;
for(;i<j;i++,j++);
}
