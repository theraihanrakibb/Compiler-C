//testcase to check struct and uninon operations
#include<stdio.h>
struct Node {
	int data;
};
union Node2{
	int w;
};

int main(){
	struct Node x;
	printf("\nEnjter Number : ");
	scanf("%d",&x->data);
	return 1;
}
