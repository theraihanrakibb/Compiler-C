//Testcase to check arithmatic logical and relational statements 

#include <stdio.h>
int main(){
	int a=10,c=40,b=56,d;
	a=b+c;
	a+=c;       
	a=b+c*d;
	d=b*(c+d);
	int d[100];
	d[20]=a*d[10]+c;

	b=a**c;
	c=a++c;
	


}